export interface Track {
  id: string
  title: string
  artist: string
  duration: number
  plays: number
  likesCount: number
  commentsCount: number
  genre: 'Pop' | 'Sertanejo' | 'Arrocha' | 'Funk' | 'Demo' | 'Finalizadas'
  status: 'published' | 'draft' | 'private' | 'hidden'
  cover: string
  description: string
  releasedAt: string
  lyrics?: string
}

export interface Reply {
  id: string
  userId: string
  userName: string
  userAvatar: string
  userHandle: string
  text: string
  createdAt: string
}

export interface Comment {
  id: string
  trackId: string
  userId: string
  userName: string
  userAvatar: string
  userHandle: string
  text: string
  createdAt: string
  likesCount: number
  likedByMe: boolean
  replies: Reply[]
}

export interface User {
  id: string
  name: string
  handle: string
  email: string
  avatar: string
  isAdmin: boolean
  joinedAt: string
  status: 'approved' | 'pending' | 'blocked'
  likesCount: number
  commentsCount: number
}

export interface FeedItem {
  id: string
  type: 'like' | 'comment' | 'playing' | 'new_track'
  userId?: string
  userName?: string
  userAvatar?: string
  trackId?: string
  trackTitle?: string
  trackCover?: string
  text?: string
  createdAt: string
}

export interface Notification {
  id: string
  type: 'like' | 'comment' | 'reply' | 'new_track'
  text: string
  read: boolean
  createdAt: string
  trackId?: string
}

export interface Playlist {
  id: string
  name: string
  emoji: string
  description: string
  cover: string
  trackIds: string[]
}

export type View =
  | 'login'
  | 'register'
  | 'home'
  | 'library'
  | 'track'
  | 'feed'
  | 'profile'
  | 'admin'
  | 'playlists'
