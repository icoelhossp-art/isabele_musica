import { AppProvider, useApp } from './context'
import Sidebar from './components/Sidebar'
import Player from './components/Player'
import MobileNav from './components/MobileNav'
import LoginView from './views/LoginView'
import RegisterView from './views/RegisterView'
import HomeView from './views/HomeView'
import LibraryView from './views/LibraryView'
import TrackView from './views/TrackView'
import FeedView from './views/FeedView'
import ProfileView from './views/ProfileView'
import AdminView from './views/AdminView'
import PlaylistsView from './views/PlaylistsView'

function Inner() {
  const { view, isLoggedIn } = useApp()

  if (!isLoggedIn) {
    if (view === 'register') return <RegisterView />
    return <LoginView />
  }

  const views: Record<string, React.ReactNode> = {
    home: <HomeView />,
    library: <LibraryView />,
    track: <TrackView />,
    feed: <FeedView />,
    profile: <ProfileView />,
    admin: <AdminView />,
    playlists: <PlaylistsView />,
  }

  return (
    <div className="flex min-h-screen" style={{ background: 'var(--bg)' }}>
      <Sidebar />

      <main
        className="flex flex-col flex-1 min-w-0 md:ml-[220px]"
        style={{ paddingBottom: 0 }}
      >
        {views[view] || <HomeView />}
      </main>

      <Player />
      <MobileNav />
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Inner />
    </AppProvider>
  )
}
