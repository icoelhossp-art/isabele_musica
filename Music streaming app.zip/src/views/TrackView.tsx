import { useState } from 'react'
import { useApp } from '../context'
import { formatDuration, formatPlays, timeAgo } from '../data'

export default function TrackView() {
  const {
    selectedTrackId, tracks, comments, likedTracks, toggleTrackLike,
    playTrack, currentTrack, isPlaying, toggleCommentLike, addComment,
    addReply, deleteComment, currentUser, setView,
  } = useApp()

  const track = tracks.find(t => t.id === selectedTrackId)
  const trackComments = comments.filter(c => c.trackId === selectedTrackId)
  const [commentText, setCommentText] = useState('')
  const [replyTo, setReplyTo] = useState<string | null>(null)
  const [replyText, setReplyText] = useState('')
  const [showLyrics, setShowLyrics] = useState(false)
  const [activeTab, setActiveTab] = useState<'comments' | 'lyrics'>('comments')

  if (!track) {
    return (
      <div className="flex-1 flex items-center justify-center" style={{ paddingBottom: 'var(--player-h)' }}>
        <div className="text-center">
          <div className="text-4xl mb-3">🎵</div>
          <p className="text-[var(--muted)]">Música não encontrada</p>
          <button onClick={() => setView('library')} className="mt-4 text-sm text-[#a78bfa] hover:underline">← Voltar</button>
        </div>
      </div>
    )
  }

  const isActive = currentTrack?.id === track.id
  const liked = likedTracks.has(track.id)

  function submitComment() {
    if (!commentText.trim()) return
    addComment(track!.id, commentText)
    setCommentText('')
  }

  function submitReply(commentId: string) {
    if (!replyText.trim()) return
    addReply(commentId, replyText)
    setReplyText('')
    setReplyTo(null)
  }

  return (
    <div className="flex-1 overflow-y-auto fade-in" style={{ paddingBottom: currentTrack ? 'calc(var(--player-h) + 24px)' : '24px' }}>
      {/* Back */}
      <div className="px-6 pt-4 pb-2">
        <button
          onClick={() => setView('library')}
          className="flex items-center gap-2 text-sm text-[var(--muted)] hover:text-[var(--text)] transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
          </svg>
          Voltar
        </button>
      </div>

      {/* Hero */}
      <div className="relative">
        <div className="absolute inset-0 overflow-hidden" style={{ height: '320px' }}>
          <img src={track.cover} alt="" className="w-full h-full object-cover opacity-30 blur-xl scale-110" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(7,7,9,0.5), var(--bg))' }} />
        </div>

        <div className="relative px-6 md:px-8 pt-6 pb-8 flex flex-col md:flex-row gap-8 items-start">
          <div className="flex-shrink-0">
            <img
              src={track.cover}
              alt={track.title}
              className="w-48 h-48 md:w-56 md:h-56 rounded-2xl object-cover shadow-2xl"
              style={{ boxShadow: '0 20px 60px rgba(0,0,0,0.6), 0 0 40px rgba(139,92,246,0.2)' }}
            />
          </div>

          <div className="flex-1 min-w-0 pt-2">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-data uppercase tracking-widest px-2 py-0.5 rounded"
                style={{ background: 'rgba(139,92,246,0.2)', color: '#a78bfa', border: '1px solid rgba(139,92,246,0.3)' }}>
                {track.genre}
              </span>
              {track.status === 'private' && (
                <span className="text-[10px] font-data uppercase tracking-widest px-2 py-0.5 rounded"
                  style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                  Privada
                </span>
              )}
            </div>

            <h1 className="font-display font-bold italic text-5xl md:text-6xl text-white mb-1 leading-tight">{track.title}</h1>
            <p className="font-display italic text-[var(--muted-bright)] text-xl mb-4">{track.artist}</p>
            <p className="text-sm text-[var(--muted)] mb-6 max-w-lg leading-relaxed">{track.description}</p>

            <div className="flex items-center gap-3 flex-wrap mb-4">
              <button
                onClick={() => playTrack(track)}
                className="flex items-center gap-2 px-6 py-3 rounded-full font-semibold text-white transition-all hover:scale-105"
                style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 20px rgba(139,92,246,0.4)' }}
              >
                {isActive && isPlaying ? (
                  <><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg> PAUSAR</>
                ) : (
                  <><svg className="w-5 h-5 ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg> PLAY</>
                )}
              </button>

              <button
                onClick={() => toggleTrackLike(track.id)}
                className={`flex items-center gap-2 px-5 py-3 rounded-full font-semibold transition-all hover:scale-105 ${liked ? 'text-[#ec4899]' : 'text-[var(--text)]'}`}
                style={{ background: 'var(--surface)', border: liked ? '1px solid rgba(236,72,153,0.3)' : '1px solid var(--border)' }}
              >
                {liked ? '❤️' : '🤍'} {track.likesCount} curtidas
              </button>
            </div>

            <div className="flex items-center gap-5">
              {[
                { icon: '🎧', val: formatPlays(track.plays), label: 'plays' },
                { icon: '💬', val: String(trackComments.length), label: 'comentários' },
                { icon: '⏱', val: formatDuration(track.duration), label: '' },
              ].map(({ icon, val, label }) => (
                <div key={label} className="text-center">
                  <p className="font-data text-sm font-medium text-[var(--text)]">{icon} {val}</p>
                  {label && <p className="text-[10px] text-[var(--muted)]">{label}</p>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 md:px-8">
        <div className="flex gap-6 border-b mb-6" style={{ borderColor: 'var(--border)' }}>
          {(['comments', 'lyrics'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-3 text-sm font-medium transition-colors border-b-2 -mb-px ${activeTab === tab ? 'text-[#a78bfa] border-[#8b5cf6]' : 'text-[var(--muted)] border-transparent hover:text-[var(--text)]'}`}
            >
              {tab === 'comments' ? `💬 Comentários (${trackComments.length})` : '📄 Letra'}
            </button>
          ))}
        </div>

        {activeTab === 'comments' && (
          <div className="space-y-4 max-w-2xl">
            {/* Add comment */}
            {currentUser && (
              <div className="flex gap-3 mb-6">
                <img src={currentUser.avatar} alt="" className="w-9 h-9 rounded-full object-cover flex-shrink-0" />
                <div className="flex-1">
                  <textarea
                    value={commentText}
                    onChange={e => setCommentText(e.target.value)}
                    placeholder="O que você achou dessa música?"
                    rows={2}
                    className="w-full px-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none resize-none"
                    style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
                    onFocus={e => e.currentTarget.style.borderColor = 'rgba(139,92,246,0.4)'}
                    onBlur={e => e.currentTarget.style.borderColor = 'var(--border)'}
                    onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) submitComment() }}
                  />
                  <div className="flex justify-end mt-2">
                    <button
                      onClick={submitComment}
                      disabled={!commentText.trim()}
                      className="px-5 py-2 rounded-full text-sm font-semibold text-white transition-all hover:opacity-90 disabled:opacity-40"
                      style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)' }}
                    >
                      COMENTAR
                    </button>
                  </div>
                </div>
              </div>
            )}

            {trackComments.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-4xl mb-2">💬</div>
                <p className="text-[var(--muted)]">Nenhum comentário ainda. Seja o primeiro!</p>
              </div>
            ) : (
              trackComments.map(comment => (
                <div key={comment.id} className="fade-in">
                  <div
                    className="p-4 rounded-2xl"
                    style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
                  >
                    <div className="flex items-start gap-3">
                      <img src={comment.userAvatar} alt="" className="w-9 h-9 rounded-full object-cover flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 mb-1">
                          <span className="font-semibold text-sm text-[var(--text)]">{comment.userName}</span>
                          <span className="text-xs text-[var(--muted)]">@{comment.userHandle}</span>
                          <span className="text-xs text-[var(--muted)] ml-auto font-data">{timeAgo(comment.createdAt)}</span>
                        </div>
                        <p className="text-sm text-[var(--text)] leading-relaxed mb-3">{comment.text}</p>
                        <div className="flex items-center gap-4">
                          <button
                            onClick={() => toggleCommentLike(comment.id)}
                            className={`flex items-center gap-1 text-xs transition-colors ${comment.likedByMe ? 'text-[#ec4899]' : 'text-[var(--muted)] hover:text-[var(--text)]'}`}
                          >
                            {comment.likedByMe ? '❤️' : '♡'} {comment.likesCount}
                          </button>
                          <button
                            onClick={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
                            className="text-xs text-[var(--muted)] hover:text-[#a78bfa] transition-colors"
                          >
                            ↩ Responder
                          </button>
                          {(currentUser?.id === comment.userId || currentUser?.isAdmin) && (
                            <button
                              onClick={() => deleteComment(comment.id)}
                              className="text-xs text-[var(--muted)] hover:text-[#ec4899] transition-colors ml-auto"
                            >
                              Excluir
                            </button>
                          )}
                        </div>

                        {replyTo === comment.id && currentUser && (
                          <div className="mt-3 flex gap-2">
                            <input
                              type="text"
                              value={replyText}
                              onChange={e => setReplyText(e.target.value)}
                              placeholder="Responder..."
                              className="flex-1 px-3 py-2 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none"
                              style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}
                              onKeyDown={e => { if (e.key === 'Enter') submitReply(comment.id) }}
                            />
                            <button
                              onClick={() => submitReply(comment.id)}
                              className="px-3 py-2 rounded-xl text-xs font-semibold text-white"
                              style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)' }}
                            >
                              ↩
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Replies */}
                  {comment.replies.length > 0 && (
                    <div className="ml-12 mt-2 space-y-2">
                      {comment.replies.map(r => (
                        <div key={r.id} className="p-3 rounded-xl flex gap-3"
                          style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}>
                          <img src={r.userAvatar} alt="" className="w-7 h-7 rounded-full object-cover flex-shrink-0" />
                          <div>
                            <div className="flex items-baseline gap-2 mb-0.5">
                              <span className="font-semibold text-xs text-[var(--text)]">{r.userName}</span>
                              <span className="text-[10px] text-[var(--muted)]">{timeAgo(r.createdAt)}</span>
                            </div>
                            <p className="text-xs text-[var(--muted-bright)]">{r.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'lyrics' && (
          <div className="max-w-xl">
            {track.lyrics ? (
              <div
                className="p-6 rounded-2xl font-display italic text-[var(--muted-bright)] leading-relaxed whitespace-pre-line"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
              >
                {track.lyrics}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-4xl mb-2">📄</div>
                <p className="text-[var(--muted)]">Letra não disponível ainda</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
