import { useState } from 'react'
import { useApp } from '../context'

export default function RegisterView() {
  const { register, setView } = useApp()
  const [name, setName] = useState('')
  const [handle, setHandle] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 700))
    register(name, handle, email, password)
  }

  return (
    <div className="min-h-screen flex relative overflow-hidden" style={{ background: 'var(--bg)' }}>
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1778715164590-123c999e0ef6?w=1400&h=900&fit=crop&auto=format"
          alt="" className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0" style={{ background: 'rgba(7,7,9,0.88)' }} />
        <div className="absolute top-1/3 left-1/4 w-80 h-80 rounded-full blur-3xl opacity-10"
          style={{ background: 'radial-gradient(circle, #db2777, transparent)' }} />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center w-full px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="font-display font-bold text-4xl grad mb-2">ISABELE MUSIC</h1>
          <p className="text-sm text-[var(--muted)]">Crie seu perfil e entre no clube</p>
        </div>

        <form onSubmit={handleSubmit} className="w-full max-w-sm fade-in">
          <div
            className="rounded-2xl p-6 space-y-4"
            style={{ background: 'rgba(14,14,21,0.85)', border: '1px solid var(--border-bright)', backdropFilter: 'blur(20px)' }}
          >
            <h2 className="font-display font-semibold text-lg text-[var(--text)]">Criar conta</h2>

            {[
              { label: 'Nome', val: name, set: setName, type: 'text', placeholder: 'Seu nome' },
              { label: 'Username', val: handle, set: (v: string) => setHandle(v.replace(/\s/g, '').toLowerCase()), type: 'text', placeholder: '@seuusuario' },
              { label: 'E-mail', val: email, set: setEmail, type: 'email', placeholder: 'seu@email.com' },
              { label: 'Senha', val: password, set: setPassword, type: 'password', placeholder: '••••••••' },
            ].map(({ label, val, set, type, placeholder }) => (
              <div key={label} className="space-y-1">
                <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide">{label}</label>
                <input
                  type={type}
                  value={val}
                  onChange={e => set(e.target.value)}
                  placeholder={placeholder}
                  required
                  className="w-full px-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none transition-all"
                  style={{ background: 'var(--surface-3)', border: '1px solid var(--border)' }}
                  onFocus={e => e.currentTarget.style.borderColor = 'rgba(139,92,246,0.5)'}
                  onBlur={e => e.currentTarget.style.borderColor = 'var(--border)'}
                />
              </div>
            ))}

            {/* Avatar preview */}
            {name && (
              <div className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'var(--surface-3)' }}>
                <img
                  src={`https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=8b5cf6&color=fff&size=80`}
                  alt="avatar preview"
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <p className="text-sm font-semibold text-[var(--text)]">{name || 'Seu nome'}</p>
                  <p className="text-xs text-[var(--muted)]">@{handle || 'usuario'}</p>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-50"
              style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 20px rgba(139,92,246,0.3)' }}
            >
              {loading ? 'Criando conta...' : 'CRIAR CONTA'}
            </button>
          </div>

          <button
            type="button"
            onClick={() => setView('login')}
            className="w-full mt-3 py-2 text-sm text-[var(--muted)] hover:text-[var(--text)] transition-colors"
          >
            ← Já tenho conta
          </button>
        </form>
      </div>
    </div>
  )
}
