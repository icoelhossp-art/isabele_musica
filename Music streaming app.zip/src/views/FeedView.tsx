import TopBar from '../components/TopBar'
import { useApp } from '../context'
import { timeAgo } from '../data'

const typeConfig = {
  like: { icon: '❤️', label: 'curtiu', color: '#ec4899' },
  comment: { icon: '💬', label: 'comentou em', color: '#8b5cf6' },
  playing: { icon: '🎧', label: 'está ouvindo', color: '#06b6d4' },
  new_track: { icon: '🎵', label: 'Nova música', color: '#10b981' },
}

export default function FeedView() {
  const { feedItems, openTrack, currentTrack } = useApp()

  return (
    <div className="flex-1 overflow-y-auto" style={{ paddingBottom: currentTrack ? 'calc(var(--player-h) + 24px)' : '24px' }}>
      <TopBar title="Feed" />

      <div className="px-6 md:px-8 py-6 max-w-xl">
        <p className="text-xs text-[var(--muted)] font-data uppercase tracking-widest mb-6">Atividade recente da comunidade</p>

        <div className="space-y-3">
          {feedItems.map((item, i) => {
            const cfg = typeConfig[item.type]

            if (item.type === 'new_track') {
              return (
                <button
                  key={item.id}
                  onClick={() => item.trackId && openTrack(item.trackId)}
                  className="w-full text-left p-4 rounded-2xl transition-all hover:scale-[1.01] fade-in"
                  style={{
                    background: 'linear-gradient(135deg, rgba(139,92,246,0.1), rgba(219,39,119,0.05))',
                    border: '1px solid rgba(139,92,246,0.2)',
                    animationDelay: `${i * 0.05}s`,
                  }}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0">
                      <img src={item.trackCover} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-lg">{cfg.icon}</span>
                        <span className="text-xs font-semibold uppercase tracking-wide font-data" style={{ color: cfg.color }}>Novo drop</span>
                      </div>
                      <p className="font-display font-semibold text-[var(--text)] truncate">{item.trackTitle}</p>
                      <p className="text-xs text-[var(--muted)] mt-0.5">{item.text}</p>
                    </div>
                    <span className="text-[10px] text-[var(--muted)] font-data flex-shrink-0">{timeAgo(item.createdAt)}</span>
                  </div>
                </button>
              )
            }

            return (
              <button
                key={item.id}
                onClick={() => item.trackId && openTrack(item.trackId)}
                className="w-full text-left p-4 rounded-2xl transition-all hover:bg-white/5 fade-in"
                style={{
                  background: 'var(--surface)',
                  border: '1px solid var(--border)',
                  animationDelay: `${i * 0.05}s`,
                }}
              >
                <div className="flex items-start gap-3">
                  <div className="relative flex-shrink-0">
                    <img src={item.userAvatar} alt="" className="w-10 h-10 rounded-full object-cover" />
                    <span className="absolute -bottom-1 -right-1 text-sm">{cfg.icon}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">
                      <span className="font-semibold text-[var(--text)]">{item.userName}</span>
                      <span className="text-[var(--muted)]"> {cfg.label} </span>
                      <span className="font-semibold" style={{ color: cfg.color }}>{item.trackTitle}</span>
                    </p>
                    {item.text && (
                      <p className="text-xs text-[var(--muted)] mt-1 italic">{item.text}</p>
                    )}
                    <p className="text-[10px] text-[var(--muted)] mt-1 font-data">{timeAgo(item.createdAt)}</p>
                  </div>
                  {item.trackCover && (
                    <img src={item.trackCover} alt="" className="w-12 h-12 rounded-lg object-cover flex-shrink-0 opacity-60" />
                  )}
                </div>
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
