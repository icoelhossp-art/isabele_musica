import TopBar from '../components/TopBar'
import { useApp } from '../context'
import { formatDuration, formatPlays, timeAgo } from '../data'

export default function HomeView() {
  const { tracks, likedTracks, toggleTrackLike, playTrack, currentTrack, isPlaying, openTrack, currentUser } = useApp()
  const published = tracks.filter(t => t.status === 'published' || t.status === 'private')
  const hero = published[0]
  const recent = published.slice(1, 5)

  return (
    <div className="flex-1 overflow-y-auto pb-6" style={{ paddingBottom: currentTrack ? 'calc(var(--player-h) + 24px)' : '24px' }}>
      <TopBar />

      {/* Hero — NOVO DROP */}
      {hero && (
        <div className="relative w-full overflow-hidden" style={{ height: '480px' }}>
          <img
            src={hero.cover}
            alt={hero.title}
            className="absolute inset-0 w-full h-full object-cover"
            style={{ filter: 'blur(2px) saturate(1.4)', transform: 'scale(1.05)' }}
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(7,7,9,0.3) 0%, rgba(7,7,9,0.6) 50%, var(--bg) 100%)' }} />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(7,7,9,0.85) 40%, transparent 100%)' }} />

          <div className="absolute inset-0 flex flex-col justify-end px-8 pb-10 md:px-12">
            <div className="max-w-lg fade-in">
              <div className="flex items-center gap-2 mb-4">
                <span
                  className="text-[10px] font-data font-bold uppercase tracking-[3px] px-3 py-1 rounded-full"
                  style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 20px rgba(139,92,246,0.5)' }}
                >
                  ✦ NOVO DROP
                </span>
                <span className="text-[10px] font-data text-[var(--muted)]">{timeAgo(hero.releasedAt)}</span>
              </div>

              <h2 className="font-display font-bold italic text-6xl md:text-7xl text-white mb-2 leading-none" style={{ textShadow: '0 4px 32px rgba(139,92,246,0.4)' }}>
                {hero.title}
              </h2>
              <p className="text-[var(--muted-bright)] mb-2 font-display italic">{hero.artist}</p>
              <p className="text-sm text-[var(--muted)] mb-6 max-w-sm leading-relaxed">{hero.description}</p>

              <div className="flex items-center gap-3 flex-wrap">
                <button
                  onClick={() => playTrack(hero)}
                  className="flex items-center gap-2 px-6 py-3 rounded-full font-semibold text-white transition-all hover:scale-105"
                  style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 24px rgba(139,92,246,0.5)' }}
                >
                  {currentTrack?.id === hero.id && isPlaying ? (
                    <>
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
                      PAUSAR
                    </>
                  ) : (
                    <>
                      <svg className="w-5 h-5 ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                      PLAY
                    </>
                  )}
                </button>

                <button
                  onClick={() => toggleTrackLike(hero.id)}
                  className={`flex items-center gap-2 px-5 py-3 rounded-full font-semibold transition-all hover:scale-105 ${likedTracks.has(hero.id) ? 'text-[#ec4899]' : 'text-[var(--text)]'}`}
                  style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}
                >
                  {likedTracks.has(hero.id) ? '❤️' : '🤍'} {hero.likesCount}
                </button>

                <button
                  onClick={() => openTrack(hero.id)}
                  className="px-5 py-3 rounded-full font-semibold text-[var(--muted)] transition-all hover:text-[var(--text)] hover:bg-white/5"
                  style={{ border: '1px solid var(--border)' }}
                >
                  Ver mais
                </button>
              </div>

              <div className="flex items-center gap-4 mt-4">
                <span className="font-data text-xs text-[var(--muted)]">🎧 {formatPlays(hero.plays)} plays</span>
                <span className="font-data text-xs text-[var(--muted)]">❤️ {hero.likesCount} curtidas</span>
                <span className="font-data text-xs text-[var(--muted)]">💬 {hero.commentsCount} comentários</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lançamentos */}
      <div className="px-6 md:px-8 mt-8">
        <div className="flex items-baseline justify-between mb-5">
          <h2 className="font-display font-bold text-2xl text-[var(--text)]">Lançamentos</h2>
          <button onClick={() => {}} className="text-xs text-[var(--muted)] hover:text-[#a78bfa] transition-colors">Ver todos →</button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {recent.map((track, i) => (
            <TrackCard key={track.id} track={track} index={i} />
          ))}
        </div>
      </div>

      {/* Now Playing banner */}
      {currentUser && (
        <div className="px-6 md:px-8 mt-8">
          <div
            className="rounded-2xl p-5 flex items-center gap-4"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
          >
            <div className="text-3xl">🎧</div>
            <div>
              <p className="text-xs text-[var(--muted)] font-data uppercase tracking-wide mb-1">Você está ouvindo</p>
              {currentTrack ? (
                <p className="font-display font-semibold text-[var(--text)]">{currentTrack.title} <span className="text-[var(--muted)] font-normal text-sm">— {currentTrack.artist}</span></p>
              ) : (
                <p className="text-sm text-[var(--muted)]">Selecione uma música para começar</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function TrackCard({ track, index }: { track: ReturnType<typeof useApp>['tracks'][0]; index: number }) {
  const { playTrack, currentTrack, isPlaying, likedTracks, toggleTrackLike, openTrack } = useApp()
  const active = currentTrack?.id === track.id
  const liked = likedTracks.has(track.id)

  return (
    <div
      className="track-card rounded-2xl overflow-hidden cursor-pointer group"
      style={{
        background: 'var(--surface)',
        border: active ? '1px solid rgba(139,92,246,0.4)' : '1px solid var(--border)',
        animationDelay: `${index * 0.08}s`,
        boxShadow: active ? '0 0 24px rgba(139,92,246,0.2)' : undefined,
      }}
      onClick={() => openTrack(track.id)}
    >
      <div className="relative aspect-square">
        <img src={track.cover} alt={track.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
          style={{ background: 'rgba(0,0,0,0.5)' }}>
          <button
            onClick={e => { e.stopPropagation(); playTrack(track) }}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-transform hover:scale-110"
            style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 20px rgba(139,92,246,0.6)' }}
          >
            {active && isPlaying
              ? <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
              : <svg className="w-5 h-5 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
            }
          </button>
        </div>
        {active && isPlaying && (
          <div className="absolute bottom-2 right-2 flex items-end gap-[2px]">
            {[4,7,5,8,6].map((h, i) => (
              <div key={i} className="wave-bar w-[2px] rounded-full"
                style={{ height: `${h}px`, background: 'linear-gradient(to top, #8b5cf6, #ec4899)', animationDelay: `${i * 0.1}s` }} />
            ))}
          </div>
        )}
        {track.status === 'private' && (
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full text-[9px] font-data uppercase"
            style={{ background: 'rgba(0,0,0,0.8)', border: '1px solid var(--border)', color: 'var(--muted)' }}>
            Privada
          </div>
        )}
      </div>

      <div className="p-3">
        <p className={`font-semibold text-sm truncate mb-0.5 ${active ? 'grad' : 'text-[var(--text)]'}`}>{track.title}</p>
        <p className="text-xs text-[var(--muted)] truncate mb-2">{track.artist} · {track.genre}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-data text-[10px] text-[var(--muted)]">{formatDuration(track.duration)}</span>
            <span className="font-data text-[10px] text-[var(--muted)]">·</span>
            <span className="font-data text-[10px] text-[var(--muted)]">{formatPlays(track.plays)}</span>
          </div>
          <button
            onClick={e => { e.stopPropagation(); toggleTrackLike(track.id) }}
            className="text-sm transition-transform hover:scale-125"
          >
            {liked ? '❤️' : <span className="text-[var(--muted)]">♡</span>}
          </button>
        </div>
      </div>
    </div>
  )
}
