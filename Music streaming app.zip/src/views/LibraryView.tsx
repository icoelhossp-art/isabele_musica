import { useState } from 'react'
import TopBar from '../components/TopBar'
import { useApp } from '../context'
import { formatDuration, formatPlays } from '../data'

type Genre = 'Todas' | 'Pop' | 'Sertanejo' | 'Arrocha' | 'Funk' | 'Demo' | 'Finalizadas'
type SortBy = 'Lançamento' | 'Popularidade' | 'Curtidas'

export default function LibraryView() {
  const { tracks, likedTracks, toggleTrackLike, playTrack, currentTrack, isPlaying, openTrack } = useApp()
  const [genre, setGenre] = useState<Genre>('Todas')
  const [sort, setSort] = useState<SortBy>('Lançamento')
  const [search, setSearch] = useState('')

  const genres: Genre[] = ['Todas', 'Pop', 'Sertanejo', 'Arrocha', 'Funk', 'Demo']

  let filtered = tracks.filter(t => t.status === 'published' || t.status === 'private')
  if (genre !== 'Todas') filtered = filtered.filter(t => t.genre === genre)
  if (search) filtered = filtered.filter(t =>
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    t.artist.toLowerCase().includes(search.toLowerCase())
  )
  if (sort === 'Popularidade') filtered = [...filtered].sort((a, b) => b.plays - a.plays)
  else if (sort === 'Curtidas') filtered = [...filtered].sort((a, b) => b.likesCount - a.likesCount)
  else filtered = [...filtered].sort((a, b) => b.releasedAt.localeCompare(a.releasedAt))

  return (
    <div className="flex-1 overflow-y-auto" style={{ paddingBottom: currentTrack ? 'calc(var(--player-h) + 24px)' : '24px' }}>
      <TopBar title="Músicas" />

      <div className="px-6 md:px-8 py-6">
        {/* Search */}
        <div className="relative mb-5">
          <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted)]" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="Buscar música ou artista..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full max-w-md pl-10 pr-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
            onFocus={e => e.currentTarget.style.borderColor = 'rgba(139,92,246,0.4)'}
            onBlur={e => e.currentTarget.style.borderColor = 'var(--border)'}
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 mb-2 flex-wrap">
          {genres.map(g => (
            <button
              key={g}
              onClick={() => setGenre(g)}
              className="px-4 py-1.5 rounded-full text-xs font-medium transition-all"
              style={genre === g ? {
                background: 'linear-gradient(135deg, rgba(139,92,246,0.3), rgba(219,39,119,0.2))',
                border: '1px solid rgba(139,92,246,0.4)',
                color: '#a78bfa',
              } : {
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                color: 'var(--muted)',
              }}
            >
              {g}
            </button>
          ))}
        </div>

        {/* Sort */}
        <div className="flex items-center gap-2 mb-6">
          <span className="text-xs text-[var(--muted)] font-data">Ordenar:</span>
          {(['Lançamento', 'Popularidade', 'Curtidas'] as SortBy[]).map(s => (
            <button
              key={s}
              onClick={() => setSort(s)}
              className="text-xs transition-colors"
              style={{ color: sort === s ? '#a78bfa' : 'var(--muted)' }}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Track list */}
        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-4xl mb-3">🎵</div>
            <p className="text-[var(--muted)]">Nenhuma música encontrada</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((track, i) => {
              const active = currentTrack?.id === track.id
              const liked = likedTracks.has(track.id)
              return (
                <div
                  key={track.id}
                  className="flex items-center gap-4 p-3 rounded-xl cursor-pointer group transition-all hover:bg-white/4"
                  style={{
                    background: active ? 'rgba(139,92,246,0.08)' : undefined,
                    border: active ? '1px solid rgba(139,92,246,0.2)' : '1px solid transparent',
                  }}
                  onClick={() => openTrack(track.id)}
                >
                  <span className="font-data text-xs text-[var(--muted)] w-5 text-right flex-shrink-0">{i + 1}</span>

                  <div className="relative flex-shrink-0">
                    <img src={track.cover} alt={track.title} className="w-12 h-12 rounded-lg object-cover" />
                    <button
                      onClick={e => { e.stopPropagation(); playTrack(track) }}
                      className="absolute inset-0 flex items-center justify-center rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{ background: 'rgba(0,0,0,0.6)' }}
                    >
                      {active && isPlaying
                        ? <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
                        : <svg className="w-5 h-5 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                      }
                    </button>
                    {active && isPlaying && (
                      <div className="absolute inset-0 flex items-end justify-center gap-[2px] pb-1 rounded-lg group-hover:hidden"
                        style={{ background: 'rgba(0,0,0,0.35)' }}>
                        {[4,6,5,7].map((h, j) => (
                          <div key={j} className="wave-bar w-[2px] rounded-full"
                            style={{ height: `${h}px`, background: '#8b5cf6', animationDelay: `${j * 0.1}s` }} />
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className={`font-semibold text-sm truncate ${active ? 'grad' : 'text-[var(--text)]'}`}>{track.title}</p>
                    <p className="text-xs text-[var(--muted)] truncate">{track.artist} · {track.genre}</p>
                  </div>

                  <div className="hidden md:flex items-center gap-6 text-[var(--muted)]">
                    <span className="font-data text-xs">{formatPlays(track.plays)} plays</span>
                    <span className="font-data text-xs">❤️ {track.likesCount}</span>
                    {track.status === 'private' && (
                      <span className="text-[9px] px-2 py-0.5 rounded font-data uppercase" style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--muted)' }}>Privada</span>
                    )}
                  </div>

                  <span className="font-data text-xs text-[var(--muted)] flex-shrink-0">{formatDuration(track.duration)}</span>

                  <button
                    onClick={e => { e.stopPropagation(); toggleTrackLike(track.id) }}
                    className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-all text-base hover:scale-125"
                  >
                    {liked ? '❤️' : <span className="text-[var(--muted)]">♡</span>}
                  </button>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
