import TopBar from '../components/TopBar'
import { useApp } from '../context'
import { formatDuration } from '../data'

export default function PlaylistsView() {
  const { playlists, tracks, playTrack, currentTrack, openTrack } = useApp()

  return (
    <div className="flex-1 overflow-y-auto" style={{ paddingBottom: currentTrack ? 'calc(var(--player-h) + 24px)' : '24px' }}>
      <TopBar title="Playlists" />

      <div className="px-6 md:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {playlists.map(pl => {
            const plTracks = pl.trackIds.map(id => tracks.find(t => t.id === id)).filter(Boolean) as typeof tracks
            const totalDuration = plTracks.reduce((a, t) => a + t.duration, 0)

            return (
              <div
                key={pl.id}
                className="rounded-2xl overflow-hidden fade-in"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
              >
                {/* Header */}
                <div className="relative h-32 overflow-hidden">
                  <div className="flex gap-1 h-full">
                    {plTracks.slice(0, 4).map(t => (
                      <img key={t.id} src={t.cover} alt="" className="flex-1 h-full object-cover" />
                    ))}
                  </div>
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, transparent, rgba(14,14,21,0.9))' }} />
                  <div className="absolute bottom-3 left-4">
                    <span className="text-2xl">{pl.emoji}</span>
                  </div>
                  <button
                    onClick={() => plTracks[0] && playTrack(plTracks[0])}
                    className="absolute bottom-3 right-4 w-10 h-10 rounded-full flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 16px rgba(139,92,246,0.5)' }}
                  >
                    <svg className="w-4 h-4 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                  </button>
                </div>

                <div className="p-4">
                  <h3 className="font-display font-bold text-lg text-[var(--text)] mb-0.5">{pl.name}</h3>
                  <p className="text-xs text-[var(--muted)] mb-3">{pl.description}</p>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="font-data text-xs text-[var(--muted)]">{plTracks.length} músicas</span>
                    <span className="text-[var(--border)] text-xs">·</span>
                    <span className="font-data text-xs text-[var(--muted)]">{formatDuration(totalDuration)}</span>
                  </div>

                  <div className="space-y-2">
                    {plTracks.map((t, i) => (
                      <button
                        key={t.id}
                        onClick={() => openTrack(t.id)}
                        className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors text-left"
                      >
                        <span className="font-data text-xs text-[var(--muted)] w-4">{i + 1}</span>
                        <img src={t.cover} alt="" className="w-8 h-8 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-[var(--text)] truncate">{t.title}</p>
                          <p className="text-[10px] text-[var(--muted)] truncate">{t.artist}</p>
                        </div>
                        <span className="font-data text-[10px] text-[var(--muted)]">{formatDuration(t.duration)}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
