import { useState } from 'react'
import TopBar from '../components/TopBar'
import { useApp } from '../context'
import { formatDuration, formatPlays } from '../data'
import type { Track } from '../types'

const GENRES = ['Pop', 'Sertanejo', 'Arrocha', 'Funk', 'Demo', 'Finalizadas'] as const

export default function AdminView() {
  const { adminTab, setAdminTab, tracks, users, comments, currentTrack,
    updateTrackStatus, deleteTrack, setUsers, uploadTrack } = useApp()

  const totalPlays = tracks.reduce((a, t) => a + t.plays, 0)
  const totalLikes = tracks.reduce((a, t) => a + t.likesCount, 0)
  const totalComments = tracks.reduce((a, t) => a + t.commentsCount, 0)

  const tabs = [
    { id: 'dashboard', label: '📊 Dashboard' },
    { id: 'tracks', label: '🎵 Músicas' },
    { id: 'upload', label: '⬆️ Upload' },
    { id: 'users', label: '👥 Usuários' },
    { id: 'comments', label: '💬 Comentários' },
  ]

  return (
    <div className="flex-1 overflow-y-auto" style={{ paddingBottom: currentTrack ? 'calc(var(--player-h) + 24px)' : '24px' }}>
      <TopBar title="Admin" />

      {/* Admin tabs */}
      <div className="px-6 md:px-8 pt-4">
        <div className="flex gap-1 flex-wrap mb-6 p-1 rounded-xl" style={{ background: 'var(--surface)' }}>
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setAdminTab(t.id)}
              className="px-4 py-2 rounded-lg text-xs font-medium transition-all"
              style={adminTab === t.id ? {
                background: 'linear-gradient(135deg, rgba(139,92,246,0.3), rgba(219,39,119,0.2))',
                color: '#a78bfa',
                border: '1px solid rgba(139,92,246,0.3)',
              } : { color: 'var(--muted)' }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {adminTab === 'dashboard' && <DashboardTab
          totalPlays={totalPlays}
          totalLikes={totalLikes}
          totalComments={totalComments}
          usersCount={users.length}
          tracks={tracks}
        />}
        {adminTab === 'tracks' && <TracksTab tracks={tracks} updateTrackStatus={updateTrackStatus} deleteTrack={deleteTrack} />}
        {adminTab === 'upload' && <UploadTab uploadTrack={uploadTrack} />}
        {adminTab === 'users' && <UsersTab users={users} setUsers={setUsers} />}
        {adminTab === 'comments' && <CommentsTab comments={comments} tracks={tracks} />}
      </div>
    </div>
  )
}

function DashboardTab({ totalPlays, totalLikes, totalComments, usersCount, tracks }: any) {
  const stats = [
    { label: 'Total de Plays', val: formatPlays(totalPlays), icon: '🎧', color: '#8b5cf6' },
    { label: 'Curtidas', val: formatPlays(totalLikes), icon: '❤️', color: '#ec4899' },
    { label: 'Comentários', val: String(totalComments), icon: '💬', color: '#a78bfa' },
    { label: 'Usuários', val: String(usersCount), icon: '👥', color: '#db2777' },
  ]

  const top = [...tracks].sort((a: Track, b: Track) => b.plays - a.plays).slice(0, 3)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map(s => (
          <div key={s.label} className="p-5 rounded-2xl" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <p className="text-2xl mb-2">{s.icon}</p>
            <p className="font-data font-bold text-2xl mb-0.5" style={{ color: s.color }}>{s.val}</p>
            <p className="text-xs text-[var(--muted)]">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl p-5" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
          <h3 className="font-display font-semibold text-[var(--text)] mb-4">Mais ouvidas</h3>
          <div className="space-y-3">
            {top.map((t: Track, i: number) => (
              <div key={t.id} className="flex items-center gap-3">
                <span className="font-data text-xs text-[var(--muted)] w-4">{i + 1}</span>
                <img src={t.cover} alt="" className="w-10 h-10 rounded-lg object-cover" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[var(--text)] truncate">{t.title}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                      <div className="h-full rounded-full" style={{ width: `${(t.plays / top[0].plays) * 100}%`, background: 'linear-gradient(90deg, #8b5cf6, #db2777)' }} />
                    </div>
                    <span className="font-data text-[10px] text-[var(--muted)]">{formatPlays(t.plays)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl p-5" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
          <h3 className="font-display font-semibold text-[var(--text)] mb-4">Status das músicas</h3>
          {(['published', 'private', 'draft', 'hidden'] as const).map(s => {
            const count = tracks.filter((t: Track) => t.status === s).length
            const label = { published: 'Publicadas', private: 'Privadas', draft: 'Rascunhos', hidden: 'Ocultas' }[s]
            const color = { published: '#8b5cf6', private: '#6b7280', draft: '#d97706', hidden: '#374151' }[s]
            return (
              <div key={s} className="flex items-center justify-between py-2" style={{ borderBottom: '1px solid var(--border)' }}>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: color }} />
                  <span className="text-sm text-[var(--muted)]">{label}</span>
                </div>
                <span className="font-data text-sm font-medium text-[var(--text)]">{count}</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function TracksTab({ tracks, updateTrackStatus, deleteTrack }: any) {
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null)

  return (
    <div className="space-y-3">
      {tracks.map((t: Track) => (
        <div key={t.id} className="flex items-center gap-4 p-4 rounded-xl"
          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
          <img src={t.cover} alt="" className="w-12 h-12 rounded-lg object-cover flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm text-[var(--text)] truncate">{t.title}</p>
            <div className="flex items-center gap-3 mt-0.5">
              <span className="font-data text-[10px] text-[var(--muted)]">🎧 {formatPlays(t.plays)}</span>
              <span className="font-data text-[10px] text-[var(--muted)]">❤️ {t.likesCount}</span>
              <span className="font-data text-[10px] text-[var(--muted)]">💬 {t.commentsCount}</span>
            </div>
          </div>

          <select
            value={t.status}
            onChange={e => updateTrackStatus(t.id, e.target.value)}
            className="text-xs px-3 py-1.5 rounded-lg outline-none cursor-pointer"
            style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', color: 'var(--text)' }}
          >
            <option value="published">Publicada</option>
            <option value="private">Privada</option>
            <option value="draft">Rascunho</option>
            <option value="hidden">Oculta</option>
          </select>

          {confirmDelete === t.id ? (
            <div className="flex gap-2">
              <button onClick={() => deleteTrack(t.id)} className="text-xs text-[#ec4899] hover:underline">Confirmar</button>
              <button onClick={() => setConfirmDelete(null)} className="text-xs text-[var(--muted)] hover:underline">Cancelar</button>
            </div>
          ) : (
            <button onClick={() => setConfirmDelete(t.id)} className="text-xs text-[var(--muted)] hover:text-[#ec4899] transition-colors">Excluir</button>
          )}
        </div>
      ))}
    </div>
  )
}

function UploadTab({ uploadTrack }: { uploadTrack: (t: any) => void }) {
  const [form, setForm] = useState({
    title: '', artist: 'Isabele', description: '', genre: 'Pop' as typeof GENRES[number],
    status: 'draft' as Track['status'], lyrics: '', cover: '',
  })
  const [done, setDone] = useState(false)

  const covers = [
    'https://images.unsplash.com/photo-1651870364199-fc5f9f46ac85?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1613327986042-63d4425a1a5d?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1673813296916-8da2b15c8ff0?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1688614598602-0a71fbfed6c5?w=400&h=400&fit=crop',
  ]

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.title) return
    uploadTrack({
      ...form,
      cover: form.cover || covers[0],
      duration: 180 + Math.floor(Math.random() * 120),
      releasedAt: new Date().toISOString().slice(0, 10),
    })
    setDone(true)
    setTimeout(() => { setDone(false); setForm(f => ({ ...f, title: '', description: '', lyrics: '', cover: '' })) }, 3000)
  }

  if (done) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="text-5xl mb-4">🎵</div>
        <h3 className="font-display font-bold text-2xl grad mb-2">Música adicionada!</h3>
        <p className="text-[var(--muted)]">Aparecerá na biblioteca em instantes.</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-lg space-y-4">
      <h3 className="font-display font-bold text-xl text-[var(--text)] mb-4">Nova Música</h3>

      {[
        { label: 'Nome da música', key: 'title', placeholder: 'ex: Amor de Verão' },
        { label: 'Artista', key: 'artist', placeholder: 'Isabele' },
        { label: 'Descrição', key: 'description', placeholder: 'Fala sobre...' },
      ].map(({ label, key, placeholder }) => (
        <div key={key}>
          <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide block mb-1">{label}</label>
          <input
            value={(form as any)[key]}
            onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
            placeholder={placeholder}
            className="w-full px-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
            onFocus={e => e.currentTarget.style.borderColor = 'rgba(139,92,246,0.4)'}
            onBlur={e => e.currentTarget.style.borderColor = 'var(--border)'}
          />
        </div>
      ))}

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide block mb-1">Gênero</label>
          <select
            value={form.genre}
            onChange={e => setForm(f => ({ ...f, genre: e.target.value as any }))}
            className="w-full px-4 py-3 rounded-xl text-sm outline-none"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)' }}
          >
            {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide block mb-1">Status</label>
          <select
            value={form.status}
            onChange={e => setForm(f => ({ ...f, status: e.target.value as any }))}
            className="w-full px-4 py-3 rounded-xl text-sm outline-none"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)' }}
          >
            <option value="draft">Rascunho</option>
            <option value="published">Publicada</option>
            <option value="private">Privada</option>
            <option value="hidden">Oculta</option>
          </select>
        </div>
      </div>

      {/* Cover picker */}
      <div>
        <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide block mb-2">Capa</label>
        <div className="grid grid-cols-4 gap-2">
          {covers.map(c => (
            <button
              key={c}
              type="button"
              onClick={() => setForm(f => ({ ...f, cover: c }))}
              className="aspect-square rounded-xl overflow-hidden transition-all"
              style={form.cover === c ? { outline: '2px solid #8b5cf6', outlineOffset: '2px' } : { opacity: 0.6 }}
            >
              <img src={c} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide block mb-1">Letra (opcional)</label>
        <textarea
          value={form.lyrics}
          onChange={e => setForm(f => ({ ...f, lyrics: e.target.value }))}
          placeholder="Letra da música..."
          rows={4}
          className="w-full px-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none resize-none"
          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
        />
      </div>

      {/* File upload area */}
      <div
        className="border-2 border-dashed rounded-xl p-8 text-center cursor-pointer hover:border-[#8b5cf6] transition-colors"
        style={{ borderColor: 'rgba(139,92,246,0.25)' }}
      >
        <p className="text-3xl mb-2">🎵</p>
        <p className="text-sm text-[var(--muted)]">Arraste o arquivo MP3/WAV aqui</p>
        <p className="text-xs text-[var(--muted)] mt-1">ou clique para selecionar</p>
        <span className="inline-block mt-3 text-xs font-data text-[var(--muted)] px-3 py-1 rounded-full"
          style={{ background: 'rgba(139,92,246,0.1)', border: '1px solid rgba(139,92,246,0.2)' }}>
          MP3 · WAV · MP4 até 50MB
        </span>
      </div>

      <button
        type="submit"
        className="w-full py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90"
        style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 20px rgba(139,92,246,0.3)' }}
      >
        PUBLICAR MÚSICA
      </button>
    </form>
  )
}

function UsersTab({ users, setUsers }: any) {
  const [confirm, setConfirm] = useState<string | null>(null)

  function blockUser(id: string) {
    setUsers((prev: typeof users) => prev.map((u: any) => u.id === id ? { ...u, status: u.status === 'blocked' ? 'approved' : 'blocked' } : u))
  }
  function deleteUser(id: string) {
    setUsers((prev: typeof users) => prev.filter((u: any) => u.id !== id))
    setConfirm(null)
  }

  return (
    <div className="space-y-2">
      {users.map((u: any) => (
        <div key={u.id} className="flex items-center gap-4 p-4 rounded-xl"
          style={{ background: 'var(--surface)', border: '1px solid var(--border)', opacity: u.status === 'blocked' ? 0.6 : 1 }}>
          <img src={u.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold text-[var(--text)]">{u.name}</p>
              {u.isAdmin && <span className="text-[9px] px-1.5 py-0.5 rounded font-data uppercase" style={{ background: 'rgba(139,92,246,0.2)', color: '#a78bfa' }}>Admin</span>}
              {u.status === 'blocked' && <span className="text-[9px] px-1.5 py-0.5 rounded font-data uppercase" style={{ background: 'rgba(239,68,68,0.2)', color: '#f87171' }}>Bloqueado</span>}
            </div>
            <p className="text-xs text-[var(--muted)]">@{u.handle} · {u.email}</p>
          </div>
          <div className="flex items-center gap-3 text-[var(--muted)]">
            <span className="font-data text-[10px]">❤️ {u.likesCount}</span>
            <span className="font-data text-[10px]">💬 {u.commentsCount}</span>
          </div>
          {!u.isAdmin && (
            <div className="flex gap-2">
              <button onClick={() => blockUser(u.id)} className={`text-xs transition-colors ${u.status === 'blocked' ? 'text-[#a78bfa] hover:text-[var(--text)]' : 'text-[var(--muted)] hover:text-[#ec4899]'}`}>
                {u.status === 'blocked' ? 'Desbloquear' : 'Bloquear'}
              </button>
              {confirm === u.id ? (
                <>
                  <button onClick={() => deleteUser(u.id)} className="text-xs text-[#ec4899] hover:underline">Confirmar</button>
                  <button onClick={() => setConfirm(null)} className="text-xs text-[var(--muted)] hover:underline">Cancelar</button>
                </>
              ) : (
                <button onClick={() => setConfirm(u.id)} className="text-xs text-[var(--muted)] hover:text-[#ec4899] transition-colors">Excluir</button>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

function CommentsTab({ comments, tracks }: any) {
  const { deleteComment } = useApp()
  const [confirm, setConfirm] = useState<string | null>(null)

  return (
    <div className="space-y-3">
      {comments.map((c: any) => {
        const t = tracks.find((t: Track) => t.id === c.trackId)
        return (
          <div key={c.id} className="p-4 rounded-xl" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <div className="flex items-start gap-3">
              <img src={c.userAvatar} alt="" className="w-8 h-8 rounded-full object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="text-xs font-semibold text-[var(--text)]">{c.userName}</span>
                  {t && <span className="text-[10px] text-[var(--muted)]">em <span className="text-[#a78bfa]">{t.title}</span></span>}
                </div>
                <p className="text-sm text-[var(--muted-bright)]">{c.text}</p>
              </div>
              {confirm === c.id ? (
                <div className="flex gap-2 flex-shrink-0">
                  <button onClick={() => { deleteComment(c.id); setConfirm(null) }} className="text-xs text-[#ec4899] hover:underline">Excluir</button>
                  <button onClick={() => setConfirm(null)} className="text-xs text-[var(--muted)] hover:underline">Não</button>
                </div>
              ) : (
                <button onClick={() => setConfirm(c.id)} className="text-xs text-[var(--muted)] hover:text-[#ec4899] transition-colors flex-shrink-0">Excluir</button>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
