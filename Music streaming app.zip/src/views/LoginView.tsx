import { useState } from 'react'
import { useApp } from '../context'

export default function LoginView() {
  const { login, setView } = useApp()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showReset, setShowReset] = useState(false)
  const [resetSent, setResetSent] = useState(false)

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    await new Promise(r => setTimeout(r, 600))
    const ok = login(email, password)
    if (!ok) {
      setError('E-mail não encontrado. Tente isabele@isabelemusic.com ou ana@email.com')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex relative overflow-hidden" style={{ background: 'var(--bg)' }}>
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1604277598647-eadc8645952c?w=1400&h=900&fit=crop&auto=format"
          alt=""
          className="w-full h-full object-cover opacity-25"
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(7,7,9,0.95) 40%, rgba(139,92,246,0.15) 100%)' }} />
        {/* Floating orbs */}
        <div className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
          style={{ background: 'radial-gradient(circle, #8b5cf6, transparent)' }} />
        <div className="absolute bottom-1/4 left-1/3 w-64 h-64 rounded-full blur-3xl opacity-8"
          style={{ background: 'radial-gradient(circle, #db2777, transparent)' }} />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center w-full px-4 py-12">
        {/* Logo */}
        <div className="text-center mb-10">
          <h1 className="font-display font-bold text-5xl grad mb-3 tracking-tight">
            ISABELE MUSIC
          </h1>
          <p className="font-display italic text-[var(--muted-bright)] text-lg">
            "Um lugar para ouvir antes de todo mundo."
          </p>
        </div>

        {!showReset ? (
          <form
            onSubmit={handleLogin}
            className="w-full max-w-sm space-y-4 fade-in"
          >
            <div
              className="rounded-2xl p-6 space-y-4"
              style={{ background: 'rgba(14,14,21,0.85)', border: '1px solid var(--border-bright)', backdropFilter: 'blur(20px)' }}
            >
              <div className="space-y-1">
                <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide">E-mail</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  required
                  className="w-full px-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none transition-all"
                  style={{ background: 'var(--surface-3)', border: '1px solid var(--border)' }}
                  onFocus={e => e.currentTarget.style.borderColor = 'rgba(139,92,246,0.5)'}
                  onBlur={e => e.currentTarget.style.borderColor = 'var(--border)'}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-[var(--muted)] font-data uppercase tracking-wide">Senha</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full px-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none transition-all"
                  style={{ background: 'var(--surface-3)', border: '1px solid var(--border)' }}
                  onFocus={e => e.currentTarget.style.borderColor = 'rgba(139,92,246,0.5)'}
                  onBlur={e => e.currentTarget.style.borderColor = 'var(--border)'}
                />
              </div>
              <button
                type="button"
                onClick={() => setShowReset(true)}
                className="text-xs text-[var(--muted)] hover:text-[#a78bfa] transition-colors"
              >
                Esqueceu a senha?
              </button>

              {error && (
                <div className="text-xs text-[#ec4899] p-3 rounded-xl" style={{ background: 'rgba(236,72,153,0.1)' }}>
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-50 hover:scale-[1.02]"
                style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 20px rgba(139,92,246,0.3)' }}
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    Entrando...
                  </span>
                ) : 'ENTRAR'}
              </button>
            </div>

            <button
              type="button"
              onClick={() => setView('register')}
              className="w-full py-3 rounded-xl font-semibold transition-all hover:bg-white/5 text-[var(--text)]"
              style={{ border: '1px solid var(--border-bright)' }}
            >
              CRIAR CONTA
            </button>

            <p className="text-center text-[10px] text-[var(--muted)]">
              Plataforma privada · Acesso somente por convite
            </p>
          </form>
        ) : (
          <div className="w-full max-w-sm fade-in">
            <div
              className="rounded-2xl p-6 space-y-4"
              style={{ background: 'rgba(14,14,21,0.85)', border: '1px solid var(--border-bright)', backdropFilter: 'blur(20px)' }}
            >
              {!resetSent ? (
                <>
                  <h2 className="font-display font-semibold text-[var(--text)]">Recuperar senha</h2>
                  <p className="text-sm text-[var(--muted)]">Digite seu e-mail e enviaremos um link de recuperação.</p>
                  <input
                    type="email"
                    placeholder="seu@email.com"
                    className="w-full px-4 py-3 rounded-xl text-sm text-[var(--text)] placeholder:text-[var(--muted)] outline-none"
                    style={{ background: 'var(--surface-3)', border: '1px solid var(--border)' }}
                  />
                  <button
                    onClick={() => setResetSent(true)}
                    className="w-full py-3 rounded-xl font-semibold text-white"
                    style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)' }}
                  >
                    Enviar link
                  </button>
                </>
              ) : (
                <div className="text-center py-4">
                  <div className="text-4xl mb-3">📬</div>
                  <p className="font-display font-semibold text-[var(--text)] mb-1">Link enviado!</p>
                  <p className="text-sm text-[var(--muted)]">Verifique seu e-mail.</p>
                </div>
              )}
              <button
                onClick={() => { setShowReset(false); setResetSent(false) }}
                className="w-full text-sm text-[var(--muted)] hover:text-[var(--text)] transition-colors"
              >
                ← Voltar ao login
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
