import { useState } from 'react'
import TopBar from '../components/TopBar'
import { useApp } from '../context'
import { formatPlays } from '../data'

export default function ProfileView() {
  const { currentUser, tracks, likedTracks, comments, currentTrack } = useApp()
  const [editing, setEditing] = useState(false)
  const [name, setName] = useState(currentUser?.name || '')
  const [handle, setHandle] = useState(currentUser?.handle || '')

  if (!currentUser) return null

  const likedTrackList = tracks.filter(t => likedTracks.has(t.id))
  const userComments = comments.filter(c => c.userId === currentUser.id)
  const totalPlays = likedTrackList.reduce((a, t) => a + t.plays, 0)

  return (
    <div className="flex-1 overflow-y-auto" style={{ paddingBottom: currentTrack ? 'calc(var(--player-h) + 24px)' : '24px' }}>
      <TopBar title="Perfil" />

      <div className="px-6 md:px-8 py-6 max-w-2xl">
        {/* Profile header */}
        <div
          className="rounded-2xl overflow-hidden mb-6"
          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
        >
          {/* Cover */}
          <div
            className="h-28 relative"
            style={{ background: 'linear-gradient(135deg, rgba(139,92,246,0.3), rgba(219,39,119,0.2), rgba(159,18,57,0.3))' }}
          >
            <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 30% 50%, rgba(139,92,246,0.4), transparent 60%), radial-gradient(circle at 70% 50%, rgba(219,39,119,0.3), transparent 60%)' }} />
          </div>

          <div className="px-6 pb-6">
            <div className="flex items-end gap-4 -mt-10 mb-4">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-20 h-20 rounded-full object-cover border-4"
                style={{ borderColor: 'var(--surface)', boxShadow: '0 0 20px rgba(139,92,246,0.3)' }}
              />
              <div className="flex-1 mb-2">
                {editing ? (
                  <div className="flex gap-2 flex-wrap">
                    <input
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="px-3 py-1.5 rounded-lg text-sm text-[var(--text)] outline-none"
                      style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}
                    />
                    <input
                      value={handle}
                      onChange={e => setHandle(e.target.value.replace(/\s/g, '').toLowerCase())}
                      className="px-3 py-1.5 rounded-lg text-sm text-[var(--text)] outline-none"
                      style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}
                    />
                    <button
                      onClick={() => setEditing(false)}
                      className="px-4 py-1.5 rounded-full text-xs font-semibold text-white"
                      style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)' }}
                    >
                      Salvar
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setEditing(true)}
                    className="px-4 py-2 rounded-full text-sm font-medium transition-all hover:bg-white/5"
                    style={{ border: '1px solid var(--border)', color: 'var(--muted)' }}
                  >
                    Editar perfil
                  </button>
                )}
              </div>
              {currentUser.isAdmin && (
                <span className="text-[10px] px-2 py-1 rounded font-data uppercase tracking-wide mb-2"
                  style={{ background: 'rgba(139,92,246,0.2)', color: '#a78bfa', border: '1px solid rgba(139,92,246,0.3)' }}>
                  ✦ Artista
                </span>
              )}
            </div>

            <div className="mb-4">
              <h2 className="font-display font-bold text-2xl text-[var(--text)]">{name || currentUser.name}</h2>
              <p className="text-[var(--muted)] text-sm">@{handle || currentUser.handle}</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { val: likedTracks.size, label: 'músicas curtidas', icon: '❤️' },
                { val: userComments.length, label: 'comentários', icon: '💬' },
                { val: formatPlays(totalPlays), label: 'plays juntos', icon: '🎧' },
              ].map(({ val, label, icon }) => (
                <div key={label} className="text-center p-3 rounded-xl" style={{ background: 'var(--surface-2)' }}>
                  <p className="text-xl mb-0.5">{icon}</p>
                  <p className="font-data font-medium text-lg text-[var(--text)]">{val}</p>
                  <p className="text-[10px] text-[var(--muted)]">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Liked tracks */}
        {likedTrackList.length > 0 && (
          <div className="mb-6">
            <h3 className="font-display font-semibold text-lg text-[var(--text)] mb-3">Músicas curtidas</h3>
            <div className="space-y-2">
              {likedTrackList.map(t => (
                <div key={t.id} className="flex items-center gap-3 p-3 rounded-xl"
                  style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                  <img src={t.cover} alt="" className="w-10 h-10 rounded-lg object-cover" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[var(--text)] truncate">{t.title}</p>
                    <p className="text-xs text-[var(--muted)] truncate">{t.artist} · {t.genre}</p>
                  </div>
                  <span className="text-base">❤️</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Comments */}
        {userComments.length > 0 && (
          <div>
            <h3 className="font-display font-semibold text-lg text-[var(--text)] mb-3">Seus comentários</h3>
            <div className="space-y-2">
              {userComments.map(c => {
                const t = tracks.find(t => t.id === c.trackId)
                return (
                  <div key={c.id} className="p-4 rounded-xl"
                    style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                    {t && (
                      <div className="flex items-center gap-2 mb-2">
                        <img src={t.cover} alt="" className="w-6 h-6 rounded object-cover" />
                        <span className="text-xs text-[var(--muted)] font-semibold">{t.title}</span>
                      </div>
                    )}
                    <p className="text-sm text-[var(--muted-bright)]">"{c.text}"</p>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {likedTrackList.length === 0 && userComments.length === 0 && (
          <div className="text-center py-12">
            <div className="text-4xl mb-3">🎵</div>
            <p className="text-[var(--muted)]">Comece ouvindo e curtindo músicas!</p>
          </div>
        )}
      </div>
    </div>
  )
}
