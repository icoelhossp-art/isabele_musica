import { createContext, useContext, useState, useEffect, useRef, type ReactNode } from 'react'
import type { Track, Comment, User, FeedItem, Notification, Playlist, View } from './types'
import {
  TRACKS, USERS, COMMENTS, FEED_ITEMS, NOTIFICATIONS, PLAYLISTS,
} from './data'

export interface AppCtx {
  view: View
  setView: (v: View) => void
  selectedTrackId: string | null
  openTrack: (id: string) => void

  isLoggedIn: boolean
  currentUser: User | null
  login: (email: string, password: string) => boolean
  register: (name: string, handle: string, email: string, password: string) => void
  logout: () => void

  tracks: Track[]
  likedTracks: Set<string>
  toggleTrackLike: (id: string) => void

  comments: Comment[]
  addComment: (trackId: string, text: string) => void
  toggleCommentLike: (commentId: string) => void
  addReply: (commentId: string, text: string) => void
  deleteComment: (commentId: string) => void

  feedItems: FeedItem[]
  notifications: Notification[]
  unreadCount: number
  markNotifRead: () => void

  playlists: Playlist[]
  users: User[]
  setUsers: (u: User[]) => void

  currentTrack: Track | null
  isPlaying: boolean
  progress: number
  volume: number
  playTrack: (track: Track) => void
  togglePlay: () => void
  seek: (pct: number) => void
  setVolume: (v: number) => void
  nextTrack: () => void
  prevTrack: () => void

  showNotifications: boolean
  setShowNotifications: (v: boolean) => void
  adminTab: string
  setAdminTab: (v: string) => void

  uploadTrack: (track: Omit<Track, 'id' | 'plays' | 'likesCount' | 'commentsCount'>) => void
  updateTrackStatus: (id: string, status: Track['status']) => void
  deleteTrack: (id: string) => void
}

const Ctx = createContext<AppCtx | null>(null)

export function useApp() {
  const c = useContext(Ctx)
  if (!c) throw new Error('useApp outside provider')
  return c
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<View>('login')
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [tracks, setTracks] = useState<Track[]>(TRACKS)
  const [likedTracks, setLikedTracks] = useState<Set<string>>(new Set())
  const [comments, setComments] = useState<Comment[]>(COMMENTS)
  const [notifications, setNotifications] = useState<Notification[]>(NOTIFICATIONS)
  const [users, setUsers] = useState<User[]>(USERS)
  const [playlists] = useState<Playlist[]>(PLAYLISTS)
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [volume, setVolume] = useState(80)
  const [showNotifications, setShowNotifications] = useState(false)
  const [adminTab, setAdminTab] = useState('dashboard')

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (isPlaying && currentTrack) {
      intervalRef.current = setInterval(() => {
        setProgress(p => {
          if (p >= 100) {
            nextTrack()
            return 0
          }
          return p + 100 / currentTrack.duration
        })
      }, 1000)
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [isPlaying, currentTrack])

  function login(email: string, _password: string): boolean {
    const u = users.find(u => u.email === email)
    if (!u) return false
    setCurrentUser(u)
    setIsLoggedIn(true)
    setView('home')
    return true
  }

  function register(name: string, handle: string, email: string, _password: string) {
    const newUser: User = {
      id: `u${Date.now()}`,
      name,
      handle,
      email,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=8b5cf6&color=fff&size=100`,
      isAdmin: false,
      joinedAt: new Date().toISOString().slice(0, 10),
      status: 'approved',
      likesCount: 0,
      commentsCount: 0,
    }
    setUsers(prev => [...prev, newUser])
    setCurrentUser(newUser)
    setIsLoggedIn(true)
    setView('home')
  }

  function logout() {
    setIsLoggedIn(false)
    setCurrentUser(null)
    setView('login')
    setCurrentTrack(null)
    setIsPlaying(false)
  }

  function openTrack(id: string) {
    setSelectedTrackId(id)
    setView('track')
  }

  function toggleTrackLike(id: string) {
    setLikedTracks(prev => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
        setTracks(ts => ts.map(t => t.id === id ? { ...t, likesCount: t.likesCount - 1 } : t))
      } else {
        next.add(id)
        setTracks(ts => ts.map(t => t.id === id ? { ...t, likesCount: t.likesCount + 1 } : t))
      }
      return next
    })
  }

  function addComment(trackId: string, text: string) {
    if (!currentUser || !text.trim()) return
    const newComment: Comment = {
      id: `c${Date.now()}`,
      trackId,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      userHandle: currentUser.handle,
      text: text.trim(),
      createdAt: new Date().toISOString(),
      likesCount: 0,
      likedByMe: false,
      replies: [],
    }
    setComments(prev => [newComment, ...prev])
    setTracks(ts => ts.map(t => t.id === trackId ? { ...t, commentsCount: t.commentsCount + 1 } : t))
  }

  function toggleCommentLike(commentId: string) {
    setComments(prev => prev.map(c =>
      c.id === commentId
        ? { ...c, likedByMe: !c.likedByMe, likesCount: c.likedByMe ? c.likesCount - 1 : c.likesCount + 1 }
        : c
    ))
  }

  function addReply(commentId: string, text: string) {
    if (!currentUser || !text.trim()) return
    setComments(prev => prev.map(c =>
      c.id === commentId
        ? {
          ...c,
          replies: [...c.replies, {
            id: `r${Date.now()}`,
            userId: currentUser.id,
            userName: currentUser.name,
            userAvatar: currentUser.avatar,
            userHandle: currentUser.handle,
            text: text.trim(),
            createdAt: new Date().toISOString(),
          }],
        }
        : c
    ))
  }

  function deleteComment(commentId: string) {
    const c = comments.find(c => c.id === commentId)
    if (c) {
      setTracks(ts => ts.map(t => t.id === c.trackId ? { ...t, commentsCount: Math.max(0, t.commentsCount - 1) } : t))
    }
    setComments(prev => prev.filter(c => c.id !== commentId))
  }

  function markNotifRead() {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
  }

  function playTrack(track: Track) {
    if (currentTrack?.id === track.id) {
      setIsPlaying(p => !p)
    } else {
      setCurrentTrack(track)
      setProgress(0)
      setIsPlaying(true)
      setTracks(ts => ts.map(t => t.id === track.id ? { ...t, plays: t.plays + 1 } : t))
    }
  }

  function togglePlay() {
    if (currentTrack) setIsPlaying(p => !p)
  }

  function seek(pct: number) {
    setProgress(Math.max(0, Math.min(100, pct)))
  }

  function nextTrack() {
    if (!currentTrack) return
    const published = tracks.filter(t => t.status === 'published')
    const idx = published.findIndex(t => t.id === currentTrack.id)
    const next = published[(idx + 1) % published.length]
    setCurrentTrack(next)
    setProgress(0)
    setIsPlaying(true)
  }

  function prevTrack() {
    if (!currentTrack) return
    const published = tracks.filter(t => t.status === 'published')
    const idx = published.findIndex(t => t.id === currentTrack.id)
    const prev = published[(idx - 1 + published.length) % published.length]
    setCurrentTrack(prev)
    setProgress(0)
    setIsPlaying(true)
  }

  function uploadTrack(track: Omit<Track, 'id' | 'plays' | 'likesCount' | 'commentsCount'>) {
    const newTrack: Track = {
      ...track,
      id: String(Date.now()),
      plays: 0,
      likesCount: 0,
      commentsCount: 0,
    }
    setTracks(prev => [newTrack, ...prev])
  }

  function updateTrackStatus(id: string, status: Track['status']) {
    setTracks(prev => prev.map(t => t.id === id ? { ...t, status } : t))
  }

  function deleteTrack(id: string) {
    setTracks(prev => prev.filter(t => t.id !== id))
  }

  const unreadCount = notifications.filter(n => !n.read).length
  const feedItems: FeedItem[] = FEED_ITEMS

  return (
    <Ctx.Provider value={{
      view, setView, selectedTrackId, openTrack,
      isLoggedIn, currentUser, login, register, logout,
      tracks, likedTracks, toggleTrackLike,
      comments, addComment, toggleCommentLike, addReply, deleteComment,
      feedItems, notifications, unreadCount, markNotifRead,
      playlists, users, setUsers,
      currentTrack, isPlaying, progress, volume,
      playTrack, togglePlay, seek, setVolume, nextTrack, prevTrack,
      showNotifications, setShowNotifications,
      adminTab, setAdminTab,
      uploadTrack, updateTrackStatus, deleteTrack,
    }}>
      {children}
    </Ctx.Provider>
  )
}
