import { useState } from 'react'
import { useApp } from '../context'
import NotificationsPanel from './NotificationsPanel'

interface Props {
  title?: string
}

export default function TopBar({ title }: Props) {
  const { currentUser, unreadCount, showNotifications, setShowNotifications, logout, setView } = useApp()
  const [searchQ, setSearchQ] = useState('')
  const [showUserMenu, setShowUserMenu] = useState(false)

  return (
    <>
      <header
        className="sticky top-0 z-30 flex items-center justify-between px-6 py-3 gap-4"
        style={{ background: 'rgba(7,7,9,0.8)', backdropFilter: 'blur(20px)', borderBottom: '1px solid var(--border)' }}
      >
        {/* Left: title or search */}
        <div className="flex items-center gap-4 flex-1 min-w-0">
          {title && (
            <h1 className="font-display font-bold text-xl text-[var(--text)] hidden md:block">{title}</h1>
          )}
          <div className="relative flex-1 max-w-xs">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted)]" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Buscar músicas..."
              value={searchQ}
              onChange={e => setSearchQ(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-full text-sm outline-none text-[var(--text)] placeholder:text-[var(--muted)]"
              style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}
            />
          </div>
        </div>

        {/* Right: notifications + avatar */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => { setShowNotifications(!showNotifications) }}
            className="relative p-2 rounded-full hover:bg-white/5 transition-colors"
            style={{ color: showNotifications ? '#a78bfa' : 'var(--muted)' }}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            {unreadCount > 0 && (
              <span
                className="absolute -top-0.5 -right-0.5 w-4 h-4 flex items-center justify-center text-[9px] font-bold text-white rounded-full font-data"
                style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)' }}
              >
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {currentUser && (
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(m => !m)}
                className="flex items-center gap-2 rounded-full p-0.5 hover:ring-2 hover:ring-[#8b5cf6]/40 transition-all"
              >
                <img src={currentUser.avatar} alt={currentUser.name} className="w-8 h-8 rounded-full object-cover" />
              </button>
              {showUserMenu && (
                <div
                  className="absolute right-0 top-full mt-2 w-44 rounded-xl overflow-hidden shadow-2xl z-50"
                  style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}
                >
                  <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border)' }}>
                    <p className="text-sm font-semibold text-[var(--text)]">{currentUser.name}</p>
                    <p className="text-xs text-[var(--muted)]">@{currentUser.handle}</p>
                  </div>
                  <button
                    onClick={() => { setView('profile'); setShowUserMenu(false) }}
                    className="w-full text-left px-4 py-2.5 text-sm text-[var(--muted)] hover:text-[var(--text)] hover:bg-white/5 transition-colors"
                  >
                    Meu perfil
                  </button>
                  {currentUser.isAdmin && (
                    <button
                      onClick={() => { setView('admin'); setShowUserMenu(false) }}
                      className="w-full text-left px-4 py-2.5 text-sm text-[var(--muted)] hover:text-[var(--text)] hover:bg-white/5 transition-colors"
                    >
                      Painel admin
                    </button>
                  )}
                  <button
                    onClick={() => { logout(); setShowUserMenu(false) }}
                    className="w-full text-left px-4 py-2.5 text-sm text-[#ec4899] hover:bg-[#ec4899]/10 transition-colors"
                  >
                    Sair
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </header>

      {showNotifications && <NotificationsPanel onClose={() => setShowNotifications(false)} />}
    </>
  )
}
