import { useApp } from '../context'
import type { View } from '../types'

const navItems: { view: View; label: string; icon: string }[] = [
  { view: 'home', label: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
  { view: 'library', label: 'Músicas', icon: 'M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3' },
  { view: 'playlists', label: 'Playlists', icon: 'M4 6h16M4 10h16M4 14h16M4 18h16' },
  { view: 'feed', label: 'Feed', icon: 'M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z' },
  { view: 'profile', label: 'Perfil', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
]

export default function Sidebar() {
  const { view, setView, currentUser, currentTrack } = useApp()

  return (
    <aside
      className="hidden md:flex flex-col fixed top-0 left-0 h-full z-40 w-[220px]"
      style={{
        background: 'var(--surface)',
        borderRight: '1px solid var(--border)',
        paddingBottom: currentTrack ? 'var(--player-h)' : '0',
      }}
    >
      {/* Logo */}
      <div className="px-6 pt-8 pb-6">
        <div className="font-display font-bold text-xl grad">ISABELE MUSIC</div>
        <div className="text-[10px] text-[var(--muted)] mt-0.5 font-data tracking-widest uppercase">Clube Privado</div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 space-y-1">
        {navItems.map(item => (
          <button
            key={item.view}
            onClick={() => setView(item.view)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group ${
              view === item.view
                ? 'text-white'
                : 'text-[var(--muted)] hover:text-[var(--text)] hover:bg-white/5'
            }`}
            style={view === item.view ? {
              background: 'linear-gradient(135deg, rgba(139,92,246,0.2), rgba(219,39,119,0.1))',
              borderLeft: '2px solid #8b5cf6',
            } : {}}
          >
            <svg
              className={`w-5 h-5 flex-shrink-0 ${view === item.view ? 'text-[#8b5cf6]' : 'text-[var(--muted)] group-hover:text-[var(--muted-bright)]'}`}
              fill="none" stroke="currentColor" strokeWidth={1.8} viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d={item.icon} />
            </svg>
            <span className={view === item.view ? 'grad' : ''}>{item.label}</span>
          </button>
        ))}

        {currentUser?.isAdmin && (
          <button
            onClick={() => setView('admin')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group ${
              view === 'admin'
                ? 'text-white'
                : 'text-[var(--muted)] hover:text-[var(--text)] hover:bg-white/5'
            }`}
            style={view === 'admin' ? {
              background: 'linear-gradient(135deg, rgba(139,92,246,0.2), rgba(219,39,119,0.1))',
              borderLeft: '2px solid #8b5cf6',
            } : {}}
          >
            <svg className={`w-5 h-5 flex-shrink-0 ${view === 'admin' ? 'text-[#8b5cf6]' : 'text-[var(--muted)] group-hover:text-[var(--muted-bright)]'}`}
              fill="none" stroke="currentColor" strokeWidth={1.8} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
            </svg>
            <span className={view === 'admin' ? 'grad' : ''}>Admin</span>
          </button>
        )}
      </nav>

      {/* User card */}
      {currentUser && (
        <div
          className="mx-3 mb-4 p-3 rounded-xl flex items-center gap-3"
          style={{ background: 'var(--surface-2)', border: '1px solid var(--border)' }}
        >
          <img src={currentUser.avatar} alt={currentUser.name} className="w-9 h-9 rounded-full object-cover ring-2 ring-[#8b5cf6]/30" />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold truncate text-[var(--text)]">{currentUser.name}</p>
            <p className="text-[10px] text-[var(--muted)] truncate">@{currentUser.handle}</p>
          </div>
          {currentUser.isAdmin && (
            <span className="text-[9px] px-1.5 py-0.5 rounded font-data uppercase tracking-wide"
              style={{ background: 'rgba(139,92,246,0.2)', color: '#a78bfa' }}>
              Admin
            </span>
          )}
        </div>
      )}
    </aside>
  )
}
