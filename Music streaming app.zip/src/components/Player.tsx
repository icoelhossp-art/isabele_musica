import { useState } from 'react'
import { useApp } from '../context'
import { formatDuration } from '../data'

export default function Player() {
  const { currentTrack, isPlaying, progress, volume, togglePlay, seek, setVolume, nextTrack, prevTrack, likedTracks, toggleTrackLike } = useApp()
  const [hoveringBar, setHoveringBar] = useState(false)

  if (!currentTrack) return null

  const elapsed = Math.floor((currentTrack.duration * progress) / 100)
  const isLiked = likedTracks.has(currentTrack.id)

  const bars = [3, 5, 8, 6, 9, 4, 7, 5, 8, 6, 4, 9, 7, 5, 6]

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50 glass"
      style={{ height: 'var(--player-h)', borderTop: '1px solid rgba(139,92,246,0.15)' }}
    >
      {/* Progress bar — full width at top */}
      <div
        className="absolute top-0 left-0 right-0 h-[3px] cursor-pointer group"
        onMouseEnter={() => setHoveringBar(true)}
        onMouseLeave={() => setHoveringBar(false)}
        onClick={e => {
          const rect = e.currentTarget.getBoundingClientRect()
          seek(((e.clientX - rect.left) / rect.width) * 100)
        }}
      >
        <div className="absolute inset-0" style={{ background: 'rgba(255,255,255,0.05)' }} />
        <div
          className="absolute top-0 left-0 h-full transition-none"
          style={{
            width: `${progress}%`,
            background: 'linear-gradient(90deg, #8b5cf6, #db2777)',
            height: hoveringBar ? '4px' : '3px',
            transition: 'height 0.1s',
          }}
        />
        {hoveringBar && (
          <div
            className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-[#8b5cf6] -translate-x-1/2"
            style={{ left: `${progress}%`, boxShadow: '0 0 8px rgba(139,92,246,0.8)' }}
          />
        )}
      </div>

      <div className="flex items-center h-full px-4 gap-4">
        {/* Track info */}
        <div className="flex items-center gap-3 w-64 min-w-0">
          <div className="relative flex-shrink-0">
            <img
              src={currentTrack.cover}
              alt={currentTrack.title}
              className="w-12 h-12 rounded-lg object-cover"
              style={{ boxShadow: '0 0 16px rgba(139,92,246,0.3)' }}
            />
            {isPlaying && (
              <div className="absolute inset-0 rounded-lg flex items-end justify-center gap-[2px] pb-1 px-1"
                style={{ background: 'rgba(0,0,0,0.45)' }}>
                {bars.slice(0, 5).map((h, i) => (
                  <div
                    key={i}
                    className="wave-bar w-[2px] rounded-full"
                    style={{
                      height: `${h}px`,
                      background: 'linear-gradient(to top, #8b5cf6, #ec4899)',
                      animationDelay: `${i * 0.12}s`,
                    }}
                  />
                ))}
              </div>
            )}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold truncate text-[var(--text)]">{currentTrack.title}</p>
            <p className="text-xs text-[var(--muted)] truncate">{currentTrack.artist}</p>
          </div>
          <button
            onClick={() => toggleTrackLike(currentTrack.id)}
            className="flex-shrink-0 ml-1 transition-transform hover:scale-110"
          >
            {isLiked ? (
              <svg className="w-4 h-4 text-[#ec4899]" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" />
              </svg>
            ) : (
              <svg className="w-4 h-4 text-[var(--muted)]" fill="none" viewBox="0 0 20 20" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" />
              </svg>
            )}
          </button>
        </div>

        {/* Controls */}
        <div className="flex-1 flex flex-col items-center gap-1">
          <div className="flex items-center gap-5">
            <button onClick={prevTrack} className="text-[var(--muted)] hover:text-[var(--text)] transition-colors">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z" />
              </svg>
            </button>

            <button
              onClick={togglePlay}
              className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-transform hover:scale-105"
              style={{ background: 'linear-gradient(135deg, #8b5cf6, #db2777)', boxShadow: '0 0 16px rgba(139,92,246,0.4)' }}
            >
              {isPlaying ? (
                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
                </svg>
              ) : (
                <svg className="w-4 h-4 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              )}
            </button>

            <button onClick={nextTrack} className="text-[var(--muted)] hover:text-[var(--text)] transition-colors">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z" />
              </svg>
            </button>
          </div>

          <div className="flex items-center gap-2 w-full max-w-xs">
            <span className="font-data text-[10px] text-[var(--muted)] w-7 text-right">{formatDuration(elapsed)}</span>
            <div
              className="flex-1 h-[3px] rounded-full cursor-pointer relative"
              style={{ background: 'rgba(255,255,255,0.08)' }}
              onClick={e => {
                const rect = e.currentTarget.getBoundingClientRect()
                seek(((e.clientX - rect.left) / rect.width) * 100)
              }}
            >
              <div
                className="absolute top-0 left-0 h-full rounded-full"
                style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #8b5cf6, #db2777)' }}
              />
            </div>
            <span className="font-data text-[10px] text-[var(--muted)] w-7">{formatDuration(currentTrack.duration)}</span>
          </div>
        </div>

        {/* Volume */}
        <div className="flex items-center gap-2 w-32 justify-end">
          <svg className="w-4 h-4 text-[var(--muted)] flex-shrink-0" fill="currentColor" viewBox="0 0 24 24">
            {volume === 0
              ? <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z" />
              : <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
            }
          </svg>
          <input
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={e => setVolume(Number(e.target.value))}
            className="w-20"
            style={{
              background: `linear-gradient(to right, #8b5cf6 ${volume}%, rgba(255,255,255,0.08) ${volume}%)`,
            }}
          />
        </div>

        {/* Waveform visual */}
        <div className="hidden md:flex items-end gap-[2px] h-8">
          {bars.map((h, i) => (
            <div
              key={i}
              className={`w-[2px] rounded-full ${isPlaying ? 'wave-bar' : ''}`}
              style={{
                height: `${h * 2}px`,
                background: isPlaying ? 'linear-gradient(to top, #8b5cf6, #ec4899)' : 'rgba(139,92,246,0.2)',
                animationDelay: `${i * 0.07}s`,
              }}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
