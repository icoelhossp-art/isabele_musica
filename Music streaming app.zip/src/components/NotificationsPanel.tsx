import { useEffect } from 'react'
import { useApp } from '../context'
import { timeAgo } from '../data'

const typeIcon: Record<string, string> = {
  like: '❤️',
  comment: '💬',
  reply: '↩️',
  new_track: '🎵',
}

export default function NotificationsPanel({ onClose }: { onClose: () => void }) {
  const { notifications, markNotifRead, openTrack } = useApp()

  useEffect(() => {
    markNotifRead()
    const handler = (e: MouseEvent) => {
      const target = e.target as Element
      if (!target.closest('[data-notif-panel]')) onClose()
    }
    setTimeout(() => document.addEventListener('click', handler), 0)
    return () => document.removeEventListener('click', handler)
  }, [])

  return (
    <div
      data-notif-panel
      className="fixed right-4 z-50 w-80 rounded-2xl overflow-hidden shadow-2xl fade-in"
      style={{
        top: '64px',
        background: 'var(--surface-2)',
        border: '1px solid var(--border-bright)',
        boxShadow: '0 20px 60px rgba(0,0,0,0.6), 0 0 0 1px rgba(139,92,246,0.1)',
      }}
    >
      <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid var(--border)' }}>
        <h3 className="font-display font-semibold text-[var(--text)]">Notificações</h3>
        <button onClick={onClose} className="text-[var(--muted)] hover:text-[var(--text)] transition-colors">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="max-h-96 overflow-y-auto">
        {notifications.length === 0 ? (
          <div className="py-12 text-center">
            <div className="text-3xl mb-2">🔔</div>
            <p className="text-sm text-[var(--muted)]">Nenhuma notificação</p>
          </div>
        ) : (
          notifications.map(n => (
            <button
              key={n.id}
              onClick={() => { if (n.trackId) { openTrack(n.trackId); onClose() } }}
              className="w-full flex items-start gap-3 px-5 py-3.5 hover:bg-white/5 transition-colors text-left"
              style={{ borderBottom: '1px solid var(--border)' }}
            >
              <span className="text-lg flex-shrink-0 mt-0.5">{typeIcon[n.type] || '🔔'}</span>
              <div className="flex-1 min-w-0">
                <p className={`text-sm leading-snug ${n.read ? 'text-[var(--muted)]' : 'text-[var(--text)]'}`}>
                  {n.text}
                </p>
                <p className="text-[10px] text-[var(--muted)] mt-1 font-data">{timeAgo(n.createdAt)}</p>
              </div>
              {!n.read && (
                <div className="w-2 h-2 rounded-full flex-shrink-0 mt-1.5" style={{ background: '#8b5cf6' }} />
              )}
            </button>
          ))
        )}
      </div>
    </div>
  )
}
