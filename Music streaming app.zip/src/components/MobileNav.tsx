import { useApp } from '../context'
import type { View } from '../types'

const items: { view: View; label: string; emoji: string }[] = [
  { view: 'home', label: 'Home', emoji: '🏠' },
  { view: 'library', label: 'Músicas', emoji: '🎵' },
  { view: 'feed', label: 'Feed', emoji: '💬' },
  { view: 'profile', label: 'Perfil', emoji: '👤' },
]

export default function MobileNav() {
  const { view, setView, currentTrack } = useApp()

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 flex"
      style={{
        background: 'rgba(14,14,21,0.95)',
        backdropFilter: 'blur(20px)',
        borderTop: '1px solid var(--border)',
        paddingBottom: currentTrack ? 'var(--player-h)' : '0',
      }}
    >
      {items.map(item => (
        <button
          key={item.view}
          onClick={() => setView(item.view)}
          className={`flex-1 flex flex-col items-center py-3 gap-1 text-xs transition-all ${
            view === item.view ? 'text-[#a78bfa]' : 'text-[var(--muted)]'
          }`}
        >
          <span className="text-lg leading-none">{item.emoji}</span>
          <span className="text-[10px]">{item.label}</span>
        </button>
      ))}
    </nav>
  )
}
